'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
const input = require('./input');
exports.input = input;
const output = require('./output');
exports.output = output;
