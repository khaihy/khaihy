import { Payment, PaymentOpts } from './index';
export declare function p2pk(a: Payment, opts?: PaymentOpts): Payment;
