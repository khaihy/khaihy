import { Payment, PaymentOpts } from './index';
export declare function p2data(a: Payment, opts?: PaymentOpts): Payment;
