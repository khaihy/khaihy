import { Payment, PaymentOpts } from './index';
export declare function p2sh(a: Payment, opts?: PaymentOpts): Payment;
