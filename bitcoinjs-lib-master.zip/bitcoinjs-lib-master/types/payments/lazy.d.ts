export declare function prop(object: {}, name: string, f: () => any): void;
export declare function value<T>(f: () => T): () => T;
