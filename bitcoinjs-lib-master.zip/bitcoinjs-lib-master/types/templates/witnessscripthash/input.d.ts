/// <reference types="node" />
export declare function check(chunks: Buffer[], allowIncomplete?: boolean): boolean;
export declare namespace check {
    var toJSON: () => string;
}
