/* Auto-generated config file hpl_aes_config.h */
#ifndef HPL_AES_CONFIG_H
#define HPL_AES_CONFIG_H

// <<< Use Configuration Wizard in Context Menu >>>

// <h> Advanced configurations

// <q> Run In Debug
// <i> Indicates whether the AES to continue normal operation during debug mode
// <id> aes_dbgctrl
#ifndef CONF_AES_DBGCTRL
#define CONF_AES_DBGCTRL 0
#endif

// </h>

// <<< end of configuration section >>>

#endif // HPL_AES_CONFIG_H
