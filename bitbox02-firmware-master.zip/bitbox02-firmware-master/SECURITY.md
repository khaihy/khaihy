<img src="./doc/BB02_logo_github.svg" width="345px"/>

# Security Policy

## Reporting a Vulnerability

Please disclose any vulnurability responsibly through our [bug bounty program](https://shiftcrypto.ch/bug-bounty-program).
